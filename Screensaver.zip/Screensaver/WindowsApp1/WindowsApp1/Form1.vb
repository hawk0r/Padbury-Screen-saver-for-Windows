﻿Public Class Form1




    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Cursor.Position = New Point(0, 0)
        Me.TopMost = True



        Cursor.Hide()
        'sets the form size
        Me.Size = Screen.PrimaryScreen.WorkingArea.Size

        'sizes the panel
        Panel1.Width = Me.Width / 0.5
        Panel1.Height = Me.Height / 3

        'centers panel1 in form
        Panel1.Location = New Point((Me.Width - Panel1.Width) \ 2, (Me.Height - Panel1.Height) \ 2)



        ' sets the size for label4 same as panel1
        Label4.Width = Panel1.Width
        Label4.Height = Panel1.Height

        'positions the label4 in center of panel
        Label4.Top = Panel1.Height / 2 - Label4.Height / 2
        Label4.Left = Panel1.Width / 2 - Label4.Width / 2

        ' sets the size for label5 same as panel1
        Label5.Width = Panel1.Width
        Label5.Height = Panel1.Height

        'positions the label5 in center of panel
        Label5.Top = Panel1.Height / 2 - Label5.Height / 2
        Label5.Left = Panel1.Width / 2 - Label5.Width / 2



        Timer1.Enabled = True
        Timer1.Interval = 100








    End Sub

    Private Sub Label1_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick

        Label4.Text = DateTime.Now.ToString("HH mm ss")
        Label5.Text = DateTime.Now.ToString("hh mm ss")





    End Sub



    Private Sub Label1_MouseHover(sender As Object, e As EventArgs)

    End Sub

    Private Sub Form1_MouseMove(sender As Object, e As MouseEventArgs) Handles MyBase.MouseMove


    End Sub

    Private Sub DateTimePicker1_ValueChanged(sender As Object, e As EventArgs)

    End Sub

    Private Sub Label4_MouseMove(sender As Object, e As MouseEventArgs) Handles Label4.MouseMove
        Me.Close()

    End Sub

    Private Sub Form1_KeyDown(sender As Object, e As KeyEventArgs) Handles Me.KeyDown
        If e.KeyCode = Keys.A Then
            If Label5.Visible = True Then
                Label5.Visible = False
            Else
                Label5.Visible = True

            End If


        End If
        If e.KeyCode = Keys.L Then
            If Me.BackColor = Color.Black Then
                Me.BackColor = Color.White
            Else
                Me.BackColor = Color.Black

            End If

            If ((Label5.ForeColor = Color.Black) And (Label4.ForeColor = Color.Black)) Then
                Label5.ForeColor = Color.White
                Label4.ForeColor = Color.White
            Else
                Label5.ForeColor = Color.Black
                Label4.ForeColor = Color.Black

            End If

        End If



    End Sub

    Private Sub Form1_MouseDown(sender As Object, e As MouseEventArgs) Handles MyBase.MouseDown

    End Sub

    Private Sub Form1_Click(sender As Object, e As EventArgs) Handles Me.Click

    End Sub

    Private Sub Form1_DoubleClick(sender As Object, e As EventArgs) Handles Me.DoubleClick

    End Sub

    Private Sub Form1_KeyPress(sender As Object, e As KeyPressEventArgs) Handles Me.KeyPress

    End Sub

    Private Sub Label5_MouseMove(sender As Object, e As MouseEventArgs) Handles Label5.MouseMove
        Me.Close()
    End Sub

    Private Sub Panel1_MouseHover(sender As Object, e As EventArgs) Handles Panel1.MouseHover
        Me.Close()
    End Sub

    Private Sub Panel1_MouseMove(sender As Object, e As MouseEventArgs) Handles Panel1.MouseMove
        Me.Close()

    End Sub
End Class
